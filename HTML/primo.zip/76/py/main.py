
from js import document


def calcola(event):
    casella1=document.getElementById("numero1")
    casella2=document.getElementById("numero2")
    valore1=casella1.value;
    valore2=casella2.value;
    d=document.getElementById("output")
    d.textContent=int(valore1)+int(valore2)
    return None










