from js import document
import random
textContent
n=random.sample(range(0, 15), 2)
document.getElementById('d'+str(n[1])).textContent=2
document.getElementById('d'+str(n[0])).textContent=2

def genera():
    generato=0
    while generato==0:
        x=random.randint(0, 15)
        if document.getElementById('d'+str(x)).textContent=="":
            document.getElementById('d'+str(x)).textContent="2"
            generato=1
    return None

def su(event):
    for i in range(15, 4, -1):
        div=document.getElementById('d'+str(i))
        sopra=document.getElementById('d'+str(i-4))
        if div.textContent==sopra.textContent
    genera()
