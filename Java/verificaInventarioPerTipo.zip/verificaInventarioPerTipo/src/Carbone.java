public class Carbone {
    private String colore;
    private int quantita;

    public Carbone(String colore, int quantita) {
        this.colore = colore;
        this.quantita = quantita;
    }

    public String getColore() {
        return colore;
    }

    public int getQuantita() {
        return quantita;
    }

    @Override
    public String toString() {
        return "Carbone;"+colore+";"+quantita;
    }
}
